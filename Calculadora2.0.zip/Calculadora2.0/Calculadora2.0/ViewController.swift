//
//  ViewController.swift
//  Calculadora2.0
//
//  Created by Alumno on 12/02/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

